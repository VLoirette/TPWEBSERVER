package com.uca.dao;

import com.uca.entity.ArticleEntity;
import com.uca.entity.UserEntity;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserDAO extends _Generic<UserEntity> {
    public ArrayList<UserEntity> getAllUsers()
    {
        ArrayList<UserEntity> entities = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = this.connect.prepareStatement("SELECT * FROM users WHERE status != 3 ORDER BY id ASC;");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                UserEntity entity = new UserEntity();
                setEntity(entity, resultSet);
                entities.add(entity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return entities;
    }

    public UserEntity getUserInfo(String username){
        UserEntity entity = new UserEntity();

        try {
            PreparedStatement preparedStatement = this.connect.prepareStatement("SELECT * FROM users WHERE username = ?;");
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                setEntity(entity, resultSet);
            }
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return entity;
    }

    private void setEntity(UserEntity entity, ResultSet resultSet) throws SQLException {
        entity.setId(resultSet.getInt("id"));
        entity.setUsername(resultSet.getString("username"));
        entity.setPassword(resultSet.getString("password"));
        entity.setStatus(resultSet.getInt("status"));
        entity.setIs_banned(resultSet.getBoolean("is_banned"));
    }

    @Override
    public UserEntity create(UserEntity obj) {
        return null;
    }

    @Override
    public void delete(UserEntity obj) {

    }
}
