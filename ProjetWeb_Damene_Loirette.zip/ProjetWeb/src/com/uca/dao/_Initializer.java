package com.uca.dao;

import com.uca.core.UserCore;
import com.uca.entity.UserEntity;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.*;

public class _Initializer {

    public static void Init(){
        Connection connection = _Connector.getInstance();

        try {
            PreparedStatement statement;
            //Init articles table
            statement = connection.prepareStatement("CREATE TABLE IF NOT EXISTS articles (id int primary key auto_increment, name varchar(100), author varchar(100), created_at timestamp, content longnvarchar(25000)); ");
            statement.executeUpdate();
            statement = connection.prepareStatement("CREATE TABLE IF NOT EXISTS users (id int primary key auto_increment, username varchar(100), password varchar(100),email varchar(100),status int, is_banned boolean);");
            statement.executeUpdate();
            statement = connection.prepareStatement("CREATE TABLE IF NOT EXISTS commentaries (id int primary key auto_increment, id_article int, id_parent int , author varchar(100), content longvarchar(25000), created_at timestamp);");
            statement.executeUpdate();

            /*statement = connection.prepareStatement("INSERT INTO users(username, password, email, status, is_banned) VALUES(?,?,?,?,?);");
            statement.setString(1, "superadmin");
            System.out.println("Before hashing");
            String hsh = UserCore.hashPassword("superadmin");
            statement.setString(2,hsh);
            System.out.println("After hashing");
            statement.setString(3, "superadmin@desesmorts.com");
            statement.setInt(4, 3);
            statement.setBoolean(5,false);
            statement.executeUpdate();*/
            /*Status : 1 = user; 2 = admin; 3 = superadmin*/

        } catch (Exception e){
            System.out.println(e.toString());
            throw new RuntimeException("could not create database !");
        }
    }
}

            //Creation du superadmin
            /*statement = connection.prepareStatement("INSERT INTO users(username, password, email, status, is_banned) VALUES(?,?,?,?,?)");
            statement.setString(1, "superadmin");
            statement.setString(2, UserCore.hashPassword("superadmin"));
            statement.setString(3, "superadmin@desesmorts.com");
            statement.setInt(4, 3);
            statement.setBoolean(5,false);
            statement.executeUpdate();*/

            //Creation d'un article, exemple du prof
            /* statement = connection.prepareStatement("INSERT INTO articles(name, author, created_at, content) VALUES(?, ?, ?, ?);");
            statement.setString(1, "Bonjour !");
            statement.setString(2, "Florian");
            statement.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            statement.setString(4, "Voici le contenu de mon article");
            statement.executeUpdate();*/