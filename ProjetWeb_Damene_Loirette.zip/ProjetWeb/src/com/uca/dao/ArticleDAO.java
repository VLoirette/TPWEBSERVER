package com.uca.dao;

import com.uca.entity.ArticleEntity;

import java.sql.*;
import java.util.ArrayList;

public class ArticleDAO extends _Generic<ArticleEntity> {

    public ArrayList<ArticleEntity> getAllArticles() {
        ArrayList<ArticleEntity> entities = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = this.connect.prepareStatement("SELECT * FROM articles ORDER BY created_at DESC;");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                ArticleEntity entity = new ArticleEntity();
                setEntity(entity, resultSet);

                entities.add(entity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return entities;
    }

    public ArrayList<ArticleEntity> getAllArticlesFromAuthor(String authName){
        ArrayList<ArticleEntity> entities = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = this.connect.prepareStatement("SELECT * FROM articles WHERE author = ? ORDER BY created_at DESC;");
            preparedStatement.setString(1,authName);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                ArticleEntity entity = new ArticleEntity();
                setEntity(entity, resultSet);

                entities.add(entity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return entities;

    }

    @Override
    public ArticleEntity create(ArticleEntity obj) {
        //TODO !
        return null;
    }

    @Override
    public void delete(ArticleEntity obj) {
        //TODO !
    }

    public ArticleEntity getArticle(int id){

        ArticleEntity entity = new ArticleEntity();

        try {
            PreparedStatement preparedStatement = this.connect.prepareStatement("SELECT * FROM articles WHERE id = ?;");
            preparedStatement.setInt(1, id);
            ResultSet result = preparedStatement.executeQuery();
            if(result.next()){
                setEntity(entity, result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return entity;
    }
    private void setEntity(ArticleEntity entity, ResultSet resultSet) throws SQLException {
        entity.setId(resultSet.getInt("id"));
        entity.setAuthor(resultSet.getString("author"));
        entity.setContent(resultSet.getString("content"));
        entity.setCreated_time(resultSet.getTimestamp("created_at"));
        entity.setName(resultSet.getString("name"));
    }
}
