package com.uca.controller;

import com.uca.core.ArticleCore;
import com.uca.core.CommentaryCore;
import com.uca.dao.CommentaryDAO;
import com.uca.dao._Connector;
import com.uca.entity.ArticleEntity;
import com.uca.entity.CommentaryEntity;
import com.uca.gui._FreeMarkerInitializer;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import spark.Request;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainController {
    public static String accueil(Request req) throws IOException, TemplateException{
        Configuration configuration = _FreeMarkerInitializer.getContext();

        Map<String, String> token_map = getToken_Map(req);

        Map<String, Object> input = new HashMap<>();

        valueToken(input, token_map);

        Writer output = new StringWriter();
        Template template = configuration.getTemplate("base/accueil.ftl");
        template.setOutputEncoding("UTF-8");
        template.process(input ,output);

        return output.toString();
    }
    public static String secret(Request req) throws IOException, TemplateException{
        Configuration configuration = _FreeMarkerInitializer.getContext();

        Map<String, String> token_map = getToken_Map(req);

        Map<String, Object> input = new HashMap<>();

        valueToken(input, token_map);

        Writer output = new StringWriter();
        Template template = configuration.getTemplate("base/secret.ftl");
        template.setOutputEncoding("UTF-8");
        template.process(input ,output);

        return output.toString();
    }
    public static String getAllArticles(Request req) throws IOException, TemplateException {
        Configuration configuration = _FreeMarkerInitializer.getContext();

        Map<String, String> token_map = getToken_Map(req);

        Map<String, Object> input = new HashMap<>();

        valueToken(input, token_map);

        input.put("articles", ArticleCore.getAllArticles());
        input.put("title", "Liste des articles");

        Writer output = new StringWriter();
        Template template = configuration.getTemplate("articles/articles.ftl");
        template.setOutputEncoding("UTF-8");
        template.process(input, output);

        return output.toString();
    }

    public static String createArticle(Request req) throws IOException, TemplateException{
        Configuration configuration = _FreeMarkerInitializer.getContext();

        Map<String, String> token_map = getToken_Map(req);

        Map<String, Object> input = new HashMap<>();
        valueToken(input, token_map);

        Writer output = new StringWriter();
        Template template = configuration.getTemplate("articles/createArticle.ftl");
        template.setOutputEncoding("UTF-8");
        template.process(input ,output);

        return output.toString();
    }

    public static String readArticle(int id,Request req) throws IOException, TemplateException, SQLException {
        Configuration configuration = _FreeMarkerInitializer.getContext();
        Map<String, String> token_map = getToken_Map(req);

        Map<String, Object> input = new HashMap<>();
        valueToken(input, token_map);

        ArticleEntity article = ArticleCore.getArticle(id);
        ArrayList<CommentaryEntity> commentaryParent = CommentaryCore.getAllCommentaryParentFromArticle(article.getId());
        input.put("article", article);
        input.put("parentCommentaries", commentaryParent);
        input.put("sonCommentaries", CommentaryCore.getAllCommentarySonFromArticle(commentaryParent));

        Writer output = new StringWriter();
        Template template = configuration.getTemplate("articles/articleUnique.ftl");
        template.setOutputEncoding("UTF-8");
        template.process(input ,output);

        return output.toString();
    }
    public static void deleteArticle(String ID) {
        Connection connection = _Connector.getInstance();

        try {

            PreparedStatement statement = connection.prepareStatement("DELETE FROM articles WHERE id = ?;");
            statement.setString(1, ID);
            statement.executeUpdate();


        } catch (Exception e) {
            System.out.println(e.toString());
            throw new RuntimeException("could not delete element from database !");
        }
    }

    public static void postArticle(String artTitle, String authName, String content) {
        Connection connection = _Connector.getInstance();

        try {

            PreparedStatement statement = connection.prepareStatement("INSERT INTO articles(name, author, created_at, content) VALUES(?, ?, ?, ?);");
            statement.setString(1, artTitle);
            statement.setString(2, authName);
            statement.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            statement.setString(4, content);
            statement.executeUpdate();


        } catch (Exception e) {
            System.out.println(e.toString());
            throw new RuntimeException("could not create new element in database !");
        }
    }

    public static void deleteCommentary(int ID){
        Connection connection = _Connector.getInstance();

        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM commentaries WHERE id = ? OR id_parent = ?;");
            statement.setInt(1, ID);
            statement.setInt(2, ID);
            statement.executeUpdate();

        } catch (Exception e) {
            System.out.println(e.toString());
            throw new RuntimeException("could not delete element from database !");
        }
    }
    public static void editCommentary(int id_comment ,String content){
        Connection connection = _Connector.getInstance();

        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE commentaries SET content = ? WHERE id = ?;");
            statement.setString(1, content);
            statement.setInt(2, id_comment);
            statement.executeUpdate();

        } catch (Exception e) {
            System.out.println(e.toString());
            throw new RuntimeException("could not delete element from database !");
        }
    }
    public static void editArticle(int id_Article ,String content,String title){
        Connection connection = _Connector.getInstance();

        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE articles SET content = ? , name = ? WHERE id = ?;");
            statement.setString(1, content);
            statement.setString(2, title);
            statement.setInt(3, id_Article);
            statement.executeUpdate();

        } catch (Exception e) {
            System.out.println(e.toString());
            throw new RuntimeException("could not delete element from database !");
        }
    }

    public static void valueToken(Map<String, Object> input, Map<String, String> token_map){
        input.put("name", token_map.get("name"));
        input.put("status",token_map.get("status"));
        input.put("is_banned",token_map.get("is_banned"));
    }

    public static Map<String, String> getToken_Map(Request req){
        Map<String, String> token_map;
        String tok = req.cookie("auth");
        if(tok == null){
            tok = SecurityController.create_token("default", 1, false);
            token_map = SecurityController.read_token(tok);
        }
        else{
            token_map = SecurityController.read_token(tok);
        }
        return token_map;
    }

}
